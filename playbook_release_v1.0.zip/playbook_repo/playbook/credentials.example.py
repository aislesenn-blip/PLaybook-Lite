# playbook/credentials.example.py
# Copy this file to playbook/credentials.py and fill in your values.
# Do not commit playbook/credentials.py!

BRAIN_API_URL = "https://your-brain-url"
BRAIN_API_KEY = "your-brain-api-key"
